﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.TextCore;
using UnityEngine.UIElements;
using UnityEngine.UI;
using System.IO.Ports;//Puerto para Arduino
using UnityEngine.SceneManagement;


public class MovePotenciometro : MonoBehaviour
{
    public float tiempo_disparo;
    public float tiempo_disparo2;
    public float tiempdis;
    public float vel;// potenciometro 1
    public float vel2;// potenciometro 2

    private int dir; // potenciometro 1
    private int dir2; // potenciometro 2
    //--------------------------------------------------------------------------
    private int dir3; // Boton 1
    private int dir4; // Boton 2
    private int dir5; // Boton 3
                      //--------------------------------------------------------------------------
    public int lives1PLayer = 3; // Vidas jugador 1
    public GameObject live1Player1;
    public GameObject live2Player1;
    public GameObject live3Player1;
    public int lives2PLayer = 3; // Vidas jugador 2
    public GameObject live1Player2;
    public GameObject live2Player2;
    public GameObject live3Player2;
    //--------------------------------------------------------------------------
    public GameObject nave2;
    public GameObject nave1;
    public GameObject RedShot;
    public GameObject GreenShot;
    public GameObject TextoPuntos2;
    public Text TextoPuntos;
    //--------------------------------------------------------------------------
    public bool active = true; //freno para boton de cambiar pantallas
    public bool inGame = false; //saber si se esta en juego o no
    public bool freno1 = true;
    public bool freno2 = true;
    public int points = 0;
    private int pointsforwin = 200;
    private int ScreeState = 1;
    public float velocityOfTheGame = 10;
    public float EvolutionOfvelocity = 0.2f;
    public float timeGame = 0;
    //--------------------------------------------------------------------------
    private GameObject [] enemys= new GameObject[6];
    public GameObject enemy1, enemy2, enemy3, enemy4, enemy5 ;
    //canvas
    public GameObject portada;
    public GameObject win;
    public GameObject lose;
    public GameObject instructions;
    
    int direccion;

    SerialPort puerto = new SerialPort("com3", 9600);


    // Start is called before the first frame update
    void Start()
    {
        enemys[0] = enemy1;
        enemys[1] = enemy2;
        enemys[2] = enemy3;
        enemys[3] = enemy4;
        enemys[4] = enemy5;
    
        try
        {
            puerto.Open();
            puerto.ReadTimeout = 1;
        }
        catch (System.Exception)

        {
        }
    }
    // Update is called once per frame
    void Update()
    {
        if (puerto.IsOpen)
        {
            try
            {
                mover(puerto.ReadLine());
            }
            catch (System.Exception)

            {
            }
        }

        if (dir5 == 0) {

            active = true;
        }

        tiempo_disparo +=Time.deltaTime;
        if (tiempo_disparo >= tiempdis) {
            freno1 = true;
        
        }

        tiempo_disparo2 += Time.deltaTime;
        if (tiempo_disparo2 >= tiempdis)
        {
            freno2 = true;

        }

        if (inGame == true)
        {
            TextoPuntos2.SetActive(true);
            TextoPuntos.text = "Puntos: " + points + "/100";

            timeGame += Time.deltaTime;
            if (timeGame >= velocityOfTheGame)
            {
                int numberOfenemys = Random.Range(1, 3);
                for (int i = 0; i < numberOfenemys; i++)
                {
                    int newEnemy = Random.Range(1, 6);
                    float Scale = Random.Range(0.06f, 0.1f);
                    Vector3 position = new Vector3(Random.Range(-8.24f, 8.24f), 5, 0);
                    GameObject temp = Instantiate(enemys[newEnemy], position, Quaternion.identity);
                    temp.transform.localScale = new Vector3(Scale, Scale, 0);
                }
                timeGame = 0;
                velocityOfTheGame = velocityOfTheGame - EvolutionOfvelocity;
            }
           
            //pruebas con teclado
           
            if (dir4 ==1  )
            {
                if (freno1 == true )
                {

                    Vector3 temp = new Vector3(nave2.transform.position.x, nave2.transform.position.y + 0.5f, 0);
                    Instantiate(RedShot, temp, Quaternion.identity);
                    freno1 = false;
                    tiempo_disparo = 0;
                }
            }
            if (dir3 == 1 )

            {
                if (freno2 == true)
                {
                    Vector3 temp = new Vector3(nave1.transform.position.x, nave1.transform.position.y + 0.5f, 0);
                    Instantiate(GreenShot, temp, Quaternion.identity);
                    freno2 = false;
                    tiempo_disparo2 = 0;
                }
            }

           
        }
        else {
            TextoPuntos2.SetActive(false);
        }
        if (points >= pointsforwin)
        {
            ScreeState++;
            win.SetActive(true);
            inGame = false;
        }

        if (lives1PLayer == 0 || lives2PLayer == 0)
        {
            ScreeState++;
            lose.SetActive(true);
            inGame = false;
        }

      

        //cambios visuales de las vidas
        visualChangesLifes();



        // Cambios de pantalla por boton
        if (dir5 == 1) {
                if (active == true)
                {

                    switch (ScreeState)
                    {
                        case 1:
                            portada.SetActive(false);
                            instructions.SetActive(true);
                            ScreeState++;
                            break;
                        case 2:
                            instructions.SetActive(false);
                            inGame = true;
                            break;
                        case 3:
                            SceneManager.LoadScene(0, LoadSceneMode.Single);
                            break;
                    }
                    active = false;
                }   
        }
    }

    void mover(string datoArduino)
    {
            string[] datosArray = datoArduino.Split(char.Parse(","));
        if (datosArray.Length == 5)
        {
            dir = int.Parse(datosArray[0]);
            dir2 = int.Parse(datosArray[1]);
            dir3 = int.Parse(datosArray[2]);
            dir4 = int.Parse(datosArray[3]);
            dir5 = int.Parse(datosArray[4]);
            Debug.Log(dir + "  " + dir2 + dir3 + " " + dir4+ " "+dir5);
            }

        nave1.transform.position = new Vector3(dir / 100, -4, 0);
        nave2.transform.position = new Vector3(dir2 / 100, -4, 0);



    }

    void visualChangesLifes() {
        switch (lives1PLayer) {
            case 0:
            live1Player1.SetActive(false);
            break;
            case 1:
            live2Player1.SetActive(false);
            break ;
            case 2:
            live3Player1.SetActive(false);
            break;
      
        }
        switch (lives2PLayer)
        {
            case 0:
                live1Player2.SetActive(false);
                break;
            case 1:
                live2Player2.SetActive(false);
                break;
            case 2:
                live3Player2.SetActive(false);
                break;
        }

    }

}








