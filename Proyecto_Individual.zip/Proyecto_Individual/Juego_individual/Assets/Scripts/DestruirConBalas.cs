﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DestruirConBalas : MonoBehaviour
{
    public GameObject controlador;
    // Start is called before the first frame update
    void Start()
    {
        controlador = GameObject.FindWithTag("Control");
    }

    // Update is called once per frame
    void Update()
    {
     
        
  
    }
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "enemy")
        {
            Destroy(collision.gameObject);
            Destroy(this.gameObject);
            controlador.GetComponent<MovePotenciometro>().points += 5;
        }
    }
   
}
