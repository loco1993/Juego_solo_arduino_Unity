﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ScreenChanges : MonoBehaviour
{
    public GameObject ActualCanvas;
    public GameObject AnotherCanvas;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void basicScreenChanges()
    {
        ActualCanvas.SetActive(false);
        AnotherCanvas.SetActive(true);
    }

    public void RestartGame()
    {
        SceneManager.LoadScene(0, LoadSceneMode.Single);
    }

    public void HideScreen()
    {
        ActualCanvas.SetActive(false);
    }



}
